
        <!-- Vendor js -->
        <script src="<?php echo e(asset('assets/js/vendor.min.js')); ?>"></script>

        <!-- App js -->
        <script src="<?php echo e(asset('assets/js/app.min.js')); ?>"></script><?php /**PATH C:\xampp\htdocs\job-api\resources\views/includes/foot-comman-template.blade.php ENDPATH**/ ?>