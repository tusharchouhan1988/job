<!DOCTYPE html>
<html lang="en">

<head>
    <?php echo $__env->make('includes.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <style type="text/css">
    .text-muted {
        color: #44484a!important;
    }   
    </style>
    <?php echo $__env->yieldContent('customCss'); ?>
</head>

<body class="loading authentication-bg authentication-bg-pattern">

    <div class="account-pages my-5">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-md-8 col-lg-6 col-xl-4">
                    <div class="text-center"> 
                        <a href="index.html"> 
                        <!-- <img src="<?php echo e(asset('assets/images/logo-dark.png')); ?>" alt="" height="22" class="mx-auto"> </a>
                        <p class="text-muted mt-2 mb-4">Responsive Admin Dashboard</p> -->
                        <h3 class="page-title"><?php echo e(config('global.app_title')); ?></h3>
                        </a>
                    </div>
                    <?php echo $__env->yieldContent('content'); ?>
                </div>
            </div>
            <!-- end row -->
        </div>
        <!-- end container -->
    </div>
    <!-- end page -->
    <?php echo $__env->make('includes.foot-comman-template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->yieldContent('customJs'); ?>
</body>

</html><?php /**PATH C:\xampp\htdocs\job-api\resources\views/layouts/comman-mater-template.blade.php ENDPATH**/ ?>