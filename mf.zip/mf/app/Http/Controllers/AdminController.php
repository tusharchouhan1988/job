<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\User;
use App\Models\Job;
use App\Models\FeaturedCollage;
use Illuminate\Support\Facades\Auth;

class AdminController extends Controller
{
    public function index()
    {
        if(Auth::check()){
            $totaljob = Job::where(config('global.enable_status'))->count();
            $totalfeatured = FeaturedCollage::where(config('global.enable_status'))->count();
            return view('admin.dashboard',['totaljob' => $totaljob,'totalfeatured' => $totalfeatured]);
        }
   
        return redirect("/")->withSuccess('You are not allowed to access');
    }
}
