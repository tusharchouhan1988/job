<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Hash;
use Session;
use App\Models\User;
use Illuminate\Support\Facades\Auth;

class AuthController extends Controller
{
    public function index()
    {
        return view('Auth.login');
    }  
       
 
    public function customLogin(Request $request)
    {
        $request->validate([
            'email' => 'required',
            'password' => 'required',
        ]);
        
        $credentials = $request->only('email', 'password');



        if (Auth::attempt($credentials)) {

                    echo "<pre>";
        $u = Auth::user();
        print_r($u);
        die('ww');
            // if(Auth::user()->is_admin)
            // {
            //  return redirect()->intended('admin-dashboard')
         //                ->withSuccess('Signed in');
            // }
            // else
            // {
            //  return redirect()->intended('dashboard')
         //                ->withSuccess('Signed in');
            // }

            return redirect()->intended('admin-dashboard')
                        ->withSuccess('Signed in');
            
        }
   
        return redirect("/")->withSuccess('Login details are not valid');
    }
 
 
 
    public function registration()
    {
        return view('auth.registration');
    }
       
 
    public function customRegistration(Request $request)
    {  
        $request->validate([
            'name' => 'required',
            'email' => 'required|email|unique:users',
            'password' => 'required|min:6',
            'phone' => 'required|numeric'
        ]);
            
        $data = $request->all();
        $check = $this->create($data);
          
        return redirect("dashboard")->withSuccess('You have signed-in');
    }
 
 
    public function create(array $data)
    {
      return User::create([
        'name' => $data['name'],
        'email' => $data['email'],
        'password' => Hash::make($data['password']),
        'phone' => $request->phone
      ]);
    }    
     
 
    public function dashboard()
    {
        if(Auth::check()){
            return view('auth.dashboard');
        }
   
        return redirect("/")->withSuccess('You are not allowed to access');
    }
     
 
    public function signOut() {
        Session::flush();
        Auth::logout();
   
        return Redirect('/');
    }
}
