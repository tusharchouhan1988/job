     <div class="right-bar">

          <div data-simplebar class="h-100">

           <div class="rightbar-title">
            <a href="javascript:void(0);" class="right-bar-toggle float-end">
             <i class="mdi mdi-close"></i>
            </a>
            <h4 class="font-16 m-0 text-white">Theme Customizer</h4>
           </div>

           <!-- Tab panes -->
           <div class="tab-content pt-0">

            <div class="tab-pane active" id="settings-tab" role="tabpanel">

             <div class="p-3">
              <div class="alert alert-warning" role="alert">
               <strong>Customize </strong> the overall color scheme, Layout, etc.
              </div>

              <h6 class="fw-medium font-14 mt-4 mb-2 pb-1">Color Scheme</h6>
              <div class="form-check form-switch mb-1">
               <input type="checkbox" class="form-check-input" name="color-scheme-mode" value="light" id="light-mode-check" checked />
               <label class="form-check-label" for="light-mode-check">Light Mode</label>
              </div>

              <div class="form-check form-switch mb-1">
               <input type="checkbox" class="form-check-input" name="color-scheme-mode" value="dark" id="dark-mode-check" />
               <label class="form-check-label" for="dark-mode-check">Dark Mode</label>
              </div>

              <!-- Width -->
              <h6 class="fw-medium font-14 mt-4 mb-2 pb-1">Width</h6>
              <div class="form-check form-switch mb-1">
               <input type="checkbox" class="form-check-input" name="width" value="fluid" id="fluid-check" checked />
               <label class="form-check-label" for="fluid-check">Fluid</label>
              </div>
              <div class="form-check form-switch mb-1">
               <input type="checkbox" class="form-check-input" name="width" value="boxed" id="boxed-check" />
               <label class="form-check-label" for="boxed-check">Boxed</label>
              </div>

              <!-- Menu positions -->
              <h6 class="fw-medium font-14 mt-4 mb-2 pb-1">Menus (Leftsidebar and Topbar) Positon</h6>

              <div class="form-check form-switch mb-1">
               <input type="checkbox" class="form-check-input" name="menus-position" value="fixed" id="fixed-check" checked />
               <label class="form-check-label" for="fixed-check">Fixed</label>
              </div>

              <div class="form-check form-switch mb-1">
               <input type="checkbox" class="form-check-input" name="menus-position" value="scrollable" id="scrollable-check" />
               <label class="form-check-label" for="scrollable-check">Scrollable</label>
              </div>

              <!-- Topbar -->
              <h6 class="fw-medium font-14 mt-4 mb-2 pb-1">Topbar</h6>

              <div class="form-check form-switch mb-1">
               <input type="checkbox" class="form-check-input" name="topbar-color" value="dark" id="darktopbar-check" checked />
               <label class="form-check-label" for="darktopbar-check">Dark</label>
              </div>

              <div class="form-check form-switch mb-1">
               <input type="checkbox" class="form-check-input" name="topbar-color" value="light" id="lighttopbar-check" />
               <label class="form-check-label" for="lighttopbar-check">Light</label>
              </div>

              <div class="d-grid mt-4">
               <button class="btn btn-primary" id="resetBtn">Reset to Default</button>
               <a href="https://1.envato.market/admintoadmin" class="btn btn-danger mt-3" target="_blank"><i class="mdi mdi-basket me-1"></i> Purchase Now</a>
              </div>

             </div>

            </div>
           </div>

          </div> <!-- end slimscroll-menu-->
     </div>