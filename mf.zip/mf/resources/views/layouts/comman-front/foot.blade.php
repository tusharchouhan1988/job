 <!-- Vendor js -->
 <script src="../assets/js/vendor.min.js"></script>

 <!-- App js -->
 <script src="../assets/js/app.min.js"></script>