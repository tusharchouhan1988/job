<!DOCTYPE html>
<html lang="en">

<head>
    @include('includes.head')
    <style type="text/css">
    .text-muted {
        color: #44484a!important;
    }   
    </style>
    @yield('customCss')
</head>

<body class="loading authentication-bg authentication-bg-pattern">

    <div class="account-pages my-5">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-md-8 col-lg-6 col-xl-4">
                    <div class="text-center"> 
                        <a href="index.html"> 
                        <!-- <img src="{{ asset('assets/images/logo-dark.png') }}" alt="" height="22" class="mx-auto"> </a>
                        <p class="text-muted mt-2 mb-4">Responsive Admin Dashboard</p> -->
                        <h3 class="page-title">{{ config('global.app_title') }}</h3>
                        </a>
                    </div>
                    @yield('content')
                </div>
            </div>
            <!-- end row -->
        </div>
        <!-- end container -->
    </div>
    <!-- end page -->
    @include('includes.foot-comman-template')
    @yield('customJs')
</body>

</html>