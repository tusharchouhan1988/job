        <!-- Right Sidebar -->
      
        <!-- /Right-bar -->

        <!-- Right bar overlay-->
        <!-- <div class="rightbar-overlay"></div>
 -->
        <!-- Vendor js -->
        <script src="{{ asset('assets/js/vendor.min.js') }}"></script>

        <!-- knob plugin -->
        <script src="{{ asset('assets/libs/jquery-knob/jquery.knob.min.js') }}"></script>


        <!-- <script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/2.0.1/js/toastr.js"></script> -->
        <script src="{{asset('assets/libs/toastr/build/toastr.min.js')}}"></script>

        <script src="{{asset('assets/js/pages/toastr.init.js')}}"></script>

        <!-- <script src="{{asset('assets/js/pages/toastr_2.js')}}"></script> -->
        <!-- App js-->

        <script src="{{asset('assets/libs/selectize/js/standalone/selectize.min.js')}}"></script>
        <script src="{{asset('assets/libs/mohithg-switchery/switchery.min.js')}}"></script>
        <script src="{{asset('assets/libs/multiselect/js/jquery.multi-select.js')}}"></script>
        <script src="{{asset('assets/libs/select2/js/select2.min.js')}}"></script>
        <script src="{{asset('assets/libs/jquery-mockjax/jquery.mockjax.min.js')}}"></script>
        <script src="{{asset('assets/libs/devbridge-autocomplete/jquery.autocomplete.min.js')}}"></script>
        <script src="{{asset('assets/libs/bootstrap-touchspin/jquery.bootstrap-touchspin.min.js')}}"></script>
        <script src="{{asset('assets/libs/bootstrap-maxlength/bootstrap-maxlength.min.js')}}"></script>


        <!-- Init js-->
        <script src="{{ asset('assets/js/app.min.js') }}"></script>

 