<div class="row">
    <div class="col-12">
        <div class="page-title-box page-title-box-alt">
            <div class="page-title-right">
                <ol class="breadcrumb m-0">
                    <li class="breadcrumb-item"><a href="javascript: void(0);">Job-Portal</a></li>

                    @if(!empty($title))
                    <li class="breadcrumb-item"><a href="javascript: void(0);">{{ $title }}</a></li>
                    @else
                    <li class="breadcrumb-item"><a href="javascript: void(0);">Dashboard</a></li>
                    @endif
                </ol>
            </div> 
            @if(!empty($title))
            <h4 class="page-title">{{ $title }}</h4>
            @else
            <h4 class="page-title">Dashboard</h4>
            @endif
        </div>
    </div>
</div>